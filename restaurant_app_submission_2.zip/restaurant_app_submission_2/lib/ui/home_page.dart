import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:restaurant_app_submission_2/provider/restaurant_search_provider.dart';
import 'package:restaurant_app_submission_2/ui/restaurant_list.dart';
import 'package:restaurant_app_submission_2/ui/restaurant_search.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _bottomNavIndex = 0;
  List<BottomNavigationBarItem> _bottomNavBarItem = [
    BottomNavigationBarItem(
      icon: Icon(Icons.restaurant),
      label: 'Restaurant',
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.search),
      label: 'Search',
    ),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _bottomNavIndex,
        items: _bottomNavBarItem,
        onTap: (selectedIndex) {
          setState(() {
            _bottomNavIndex = selectedIndex;
          });
        },
      ),
      body: _bottomNavIndex == 0
          ? RestaurantList()
          : ChangeNotifierProvider(
              create: (_) => RestaurantSearchProvider(),
              child: RestaurantSearch()),
    );
  }
}
