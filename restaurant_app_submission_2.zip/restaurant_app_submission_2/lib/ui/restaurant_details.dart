import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:restaurant_app_submission_2/network/restaurantapi/api_service.dart';
import 'package:restaurant_app_submission_2/provider/add_review_provider.dart';
import 'package:restaurant_app_submission_2/provider/connectivity_provider.dart';
import 'package:restaurant_app_submission_2/provider/restaurant_details_provider.dart';
import 'package:restaurant_app_submission_2/ui/review_restaurant_form.dart';

import 'foods_drinks_list.dart';

class RestaurantDetails extends StatefulWidget {
  final String restaurantId;
  const RestaurantDetails({
    Key? key,
    required this.restaurantId,
  }) : super(key: key);

  @override
  State<RestaurantDetails> createState() => _RestaurantDetailsState();
}

class _RestaurantDetailsState extends State<RestaurantDetails> {
  @override
  void initState() {
    var provider =
        Provider.of<RestaurantDetailsProvider>(context, listen: false);
    provider.getRestaurantDetails(widget.restaurantId);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    refreshPage() {
      var connectivity =
          Provider.of<ConnectivityProvider>(context, listen: false);
      var provider =
          Provider.of<RestaurantDetailsProvider>(context, listen: false);
      connectivity.startMonitoring();
      if (connectivity.isOnline != false) {
        provider.getRestaurantDetails(widget.restaurantId);
      }
    }

    Widget restaurantDetails() {
      return Consumer<ConnectivityProvider>(builder: (context, value, child) {
        if (value.isOnline != null) {
          var provider = Provider.of<RestaurantDetailsProvider>(context);
          if (provider.restaurantDetails != null) {
            var pictureId = provider.restaurantDetails?.restaurant.pictureId;
            return provider.loading
                ? Center(
                    child: CircularProgressIndicator(),
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          Container(
                            height: 250,
                            width: double.infinity,
                            decoration: BoxDecoration(
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "https://restaurant-api.dicoding.dev/images/small/$pictureId"),
                                    fit: BoxFit.cover)),
                          ),
                          SafeArea(
                            child: Container(
                              margin: EdgeInsets.all(
                                12.0,
                              ),
                              alignment: Alignment.topLeft,
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: CircleAvatar(
                                  backgroundColor: Colors.grey,
                                  child: Icon(
                                    Icons.arrow_back,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              provider.restaurantDetails!.restaurant.name,
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 30.0,
                              ),
                            ),
                            SizedBox(
                              height: 6.0,
                            ),
                            Text(
                              provider.restaurantDetails!.restaurant.city,
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 18.0,
                              ),
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                            Row(
                              children: [
                                Icon(
                                  Icons.star,
                                  color: Colors.yellow,
                                ),
                                SizedBox(
                                  width: 6.0,
                                ),
                                Text(
                                  provider.restaurantDetails!.restaurant.rating
                                      .toString(),
                                  style: TextStyle(
                                    fontSize: 18.0,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(
                              height: 12.0,
                            ),
                            Wrap(
                              children: [
                                ...provider
                                    .restaurantDetails!.restaurant.categories
                                    .map((e) => Container(
                                        margin: EdgeInsets.only(
                                          right: 12.0,
                                        ),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(
                                            16.0,
                                          ),
                                          border: Border.all(
                                              width: 1, color: Colors.black),
                                        ),
                                        padding: EdgeInsets.symmetric(
                                          horizontal: 12.0,
                                          vertical: 8.0,
                                        ),
                                        child: Text(
                                          e.name,
                                          style: TextStyle(
                                            fontSize: 16.0,
                                          ),
                                        )))
                              ],
                            ),
                            SizedBox(
                              height: 22.0,
                            ),
                            Text(
                              "Description",
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 26.0,
                              ),
                            ),
                            SizedBox(
                              height: 8.0,
                            ),
                            Text(
                              provider
                                  .restaurantDetails!.restaurant.description,
                              textAlign: TextAlign.justify,
                              style: TextStyle(
                                fontSize: 16.0,
                              ),
                            ),
                            SizedBox(
                              height: 22.0,
                            ),
                            Text(
                              "Foods & Drinks",
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 26.0,
                              ),
                            ),
                            Container(
                              margin:
                                  const EdgeInsets.only(top: 16.0, right: 16),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) {
                                            return FoodsDrinksList(
                                                restaurant: provider
                                                    .restaurantDetails!
                                                    .restaurant,
                                                type: 'Foods');
                                          },
                                        ),
                                      );
                                    },
                                    child: Container(
                                      width: 140,
                                      height: 100,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        color: Colors.orange,
                                      ),
                                      child: Center(
                                        child: Image.asset(
                                          'assets/image_foods_logo.png',
                                          width: 100,
                                          height: 80,
                                        ),
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) {
                                            return FoodsDrinksList(
                                                restaurant: provider
                                                    .restaurantDetails!
                                                    .restaurant,
                                                type: 'Drinks');
                                          },
                                        ),
                                      );
                                    },
                                    child: Container(
                                      width: 140,
                                      height: 100,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(8),
                                        color: Colors.orange,
                                      ),
                                      child: Center(
                                        child: Image.asset(
                                          'assets/image_drinks_logo.png',
                                          width: 100,
                                          height: 70,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 40.0,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Reviews",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 26.0,
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.only(
                                    right: 8.0,
                                    top: 8.0,
                                  ),
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.push(context,
                                          MaterialPageRoute(builder: (context) {
                                        return ChangeNotifierProvider(
                                          create: (_) => AddReviewProvider(),
                                          child: ReviewRestaurantForm(
                                            restaurantId: provider
                                                .restaurantDetails!
                                                .restaurant
                                                .id,
                                            restaurantName: provider
                                                .restaurantDetails!
                                                .restaurant
                                                .name,
                                          ),
                                        );
                                      })).then((value) => refreshPage());
                                    },
                                    child: Text(
                                      "Add Review",
                                      style: TextStyle(
                                        color: Colors.blue,
                                        fontWeight: FontWeight.w500,
                                        fontSize: 16.0,
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 12.0,
                            ),
                            Container(
                              margin: EdgeInsets.symmetric(
                                horizontal: 3.0,
                                vertical: 8.0,
                              ),
                              child: Consumer<RestaurantDetailsProvider>(
                                builder: (context, value, child) {
                                  return Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      ...value.restaurantDetails!.restaurant
                                          .customerReviews
                                          .map((e) {
                                        return Container(
                                          margin: EdgeInsets.only(
                                            bottom: 20.0,
                                          ),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                e.name,
                                                style: TextStyle(
                                                  fontWeight: FontWeight.w500,
                                                  fontSize: 20.0,
                                                ),
                                              ),
                                              SizedBox(
                                                height: 3.0,
                                              ),
                                              Text(
                                                e.date,
                                                style: TextStyle(
                                                  color: Colors.grey,
                                                ),
                                              ),
                                              SizedBox(
                                                height: 6.0,
                                              ),
                                              Text(
                                                e.review,
                                                textAlign: TextAlign.justify,
                                                style: TextStyle(
                                                  fontSize: 16.0,
                                                ),
                                              )
                                            ],
                                          ),
                                        );
                                      })
                                    ],
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
          } else {
            return Container(
                alignment: Alignment.center,
                margin: EdgeInsets.only(
                  top: 300.0,
                ),
                child: CircularProgressIndicator());
          }
        } else {
          return Center(
            child: Column(
              children: [
                Icon(
                  Icons.error,
                  size: 50.0,
                ),
                SizedBox(
                  height: 12.0,
                ),
                Text(
                  "No Connection Detected,\nPlease Check Your Connection",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18.0,
                  ),
                ),
              ],
            ),
          );
        }
      });
    }

    return Scaffold(
        body: SingleChildScrollView(
      child: Container(
        child: restaurantDetails(),
      ),
    ));
  }
}
