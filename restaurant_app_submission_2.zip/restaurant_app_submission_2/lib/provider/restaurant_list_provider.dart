import 'package:flutter/material.dart';
import 'package:restaurant_app_submission_2/network/restaurantapi/api_service.dart';
import '../data/model/restaurant.dart';

class RestaurantListProvider extends ChangeNotifier {
  late RestaurantResult restaurantList;
  ApiService getApi = ApiService();
  bool loading = false;

  getRestaurantList(context) async {
    loading = true;
    print('loading...');
    print('getting data...');
    restaurantList = await getApi.getAllRestaurantList();
    print('get data done...');
    loading = false;

    notifyListeners();
  }
}
