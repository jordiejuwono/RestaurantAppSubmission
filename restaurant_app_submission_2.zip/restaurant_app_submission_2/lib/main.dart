import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';
import 'package:restaurant_app_submission_2/provider/add_review_provider.dart';
import 'package:restaurant_app_submission_2/provider/connectivity_provider.dart';
import 'package:restaurant_app_submission_2/provider/restaurant_details_provider.dart';
import 'package:restaurant_app_submission_2/provider/restaurant_list_provider.dart';
import 'package:restaurant_app_submission_2/ui/home_page.dart';
import 'package:restaurant_app_submission_2/ui/restaurant_list.dart';
import 'package:restaurant_app_submission_2/ui/splash_screen.dart';

void main() {
  runApp(RestaurantApp());
}

class RestaurantApp extends StatelessWidget {
  const RestaurantApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ConnectivityProvider(),
      child: MaterialApp(
        theme: ThemeData(
          bottomNavigationBarTheme: BottomNavigationBarThemeData(
            backgroundColor: Colors.white,
            selectedItemColor: Colors.orange,
          ),
        ),
        title: 'Restaurant App',
        home: SplashScreen(),
      ),
    );
  }
}
