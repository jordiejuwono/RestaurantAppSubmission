package com.example.restaurant_app_submission_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
